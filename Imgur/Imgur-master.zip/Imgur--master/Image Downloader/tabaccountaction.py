class SubmitButton():
	def CollectCreds(self, clientID, sharedSecret):
		if(clientID == ""):
			print("empty")
		else:
			print("not empty")
		if(sharedSecret == ""):
			print("empty")
		else:
			print("not empty")
			print("write to yaml file")
		#print(self.ui.clientIDLineEdit.text())
		#print(self.ui.clientSecretLineEdit.text())
