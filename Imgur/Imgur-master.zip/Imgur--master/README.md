# Imgur
For projects utilizing Imgur APIs

* Image downloader - Built in feature only allows download of a post up to 1000 images. Require utilizing their APIs for more

* Metrics (Maybe) - Data collection on # of posts, images/gifs, views, points in the past hour/day/week/month. Will look into hosting solution for long term data. (better served use for Reddit)

* Repost Finder - Finding reposts with hashes and image comparison (pixel level)
